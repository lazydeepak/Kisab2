package com.susankhya.foundation.session

import android.content.Context
import android.content.SharedPreferences

interface SessionStorage {
    suspend fun save(session: StoredSession)
    suspend fun read(): StoredSession?
    suspend fun clear()
}

data class StoredSession(
    val id: String,
    val payload: String
)

class InMemorySessionStorage : SessionStorage {
    private var session: StoredSession? = null

    override suspend fun save(session: StoredSession) {
        this.session = session
    }

    override suspend fun read(): StoredSession? = session

    override suspend fun clear() {
        this.session = null
    }
}

class AndroidKeystoreSessionStorage(
    private val context: Context,
    private val prefsName: String = "foundation_session_prefs",
    private val keyAlias: String = "foundation_session_key"
) : SessionStorage {

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
    }

    override suspend fun save(session: StoredSession) {
        prefs.edit()
            .putString("id", session.id)
            .putString("payload", session.payload)
            .apply()
    }

    override suspend fun read(): StoredSession? {
        val id = prefs.getString("id", null) ?: return null
        val payload = prefs.getString("payload", null) ?: return null
        return StoredSession(id = id, payload = payload)
    }

    override suspend fun clear() {
        prefs.edit().clear().apply()
    }
}
